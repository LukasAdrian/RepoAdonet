document.addEventListener('DOMContentLoaded', function() {
  const links = document.querySelectorAll('a');
  let webView; // Declaramos la variable webView aquí para poder acceder a ella en todo el ámbito

  links.forEach(function(link) {
    link.addEventListener('click', function(event) {
      event.preventDefault();
      document.body.style.backgroundColor = '#f0f0f0'; // Cambiar color de fondo al hacer clic


fetch('https://todoelfutbolgratis.pages.dev/')
  .then(response => response.text())
  .then(html => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const fragment = doc.querySelector('.tu-clase-o-selector');
    // Hacer algo con el fragmento obtenido, como insertarlo en tu página
  })
  .catch(error => {
    console.error('Hubo un error:', error);
  });


      // Si el WebView ya existe, lo eliminamos para crear uno nuevo
      if (webView) {
        document.body.removeChild(webView);
      }

      // Crear un webview
      webView = document.createElement('webview');
      webView.style.width = '100%';
      webView.style.height = '500px';
      document.body.appendChild(webView);

      // Cargar la URL del enlace en el webview
      const url = this.getAttribute('href');
      webView.src = url;
    });
  });

  // Recargar el WebView cuando se haga doble clic en el mismo enlace
  document.body.addEventListener('dblclick', function(event) {
    if (event.target.tagName === 'WEBVIEW') {
      event.preventDefault();
      webView.reload(); // Recargar el contenido del WebView
    }
  });
});
