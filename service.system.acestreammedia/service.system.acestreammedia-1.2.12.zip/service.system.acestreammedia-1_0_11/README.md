# service.system.acestreammedia
## Add-on Kodi (LibreELEC ARM)  [ACE Stream Media v.3.1.46](http://acestream.org/ru/)
