# -*- coding: utf-8 -*-

import urllib, urllib2
import re
import datetime
from libs.tools import *


def list_all_channels(item):
    itemlist = []

    data = urllib2.urlopen(urllib2.Request(item.url)).read()
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = "#EXTINF:-1,\s?\.?(.*?)\s?\(.*?acestream:\/\/(\w{40})" \


    agenda = []
    for title, channels in re.findall(patron, data, re.DOTALL):
        patron = 'acestream://(.*?)#'
        options = re.findall(patron, channels, re.DOTALL)

        logger(options,'debug')

        new_item = item.clone(
            title=title,
            action= 'list_options',
        )


    return itemlist


def list_options(item):
    itemlist = list()

    itemlist.append(item.clone(action=''))

    for op in item.options:
        itemlist.append(item.clone(
            label='Canal %s ' % (op[1]),
            action='play',
            url='plugin://program.plexus/?mode=1&url=%s&name=Video' % op[0]
        ))

    return itemlist


