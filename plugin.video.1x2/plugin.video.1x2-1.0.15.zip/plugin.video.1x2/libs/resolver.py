# -*- coding: utf-8 -*-

from libs.tools import *

def is_valido(src):

    validos = ['alieztv', 'sportsbay.org', 'video.olimp-app.ru', 'assia.tv', 'sportlive.site', 'livesport4u.pw',
               'pcast.pw', 'streamcdn.to', 'livestream.com', 'whd365.pro']

    for i in validos:
        if i in src:
            logger("resolver is_valido: %s" % src)
            return i

    no_validos = ['live-stream365.com', 'live.harleyquinnwidget.live']
    for i in no_validos:
        if i in src:
            logger("resolver NOT is_valido: %s" % src)
            return False

    logger("Servicio desconocido: %s" % src)
    return None


def get_url(src, referer = None, **kwargs):
    ret = None
    logger("resolver: %s" % src)

    if 'alieztv' in referer:
        # TODO no funciona
        logger("resolver: avezytv encontrado")
        url_head = '|Referer=%s' % urllib.quote(src)  # Referer: http://78.142.19.8/player/live.php?id=101706&w=700&h=480
        data = httptools.downloadpage(src).data
        url = re.findall("pl\.init\('([^']+)", data)[0]
        logger(url)
        return url + url_head

    elif 'sportsbay.org' in src: # https://sportsbay.org/embed/47370/1/fc-cincinnati-vs-orlando-city-sc-live.html
        logger("resolver: sportsbay.org encontrado")
        url_head = '|Referer=%s' % urllib.quote(src)
        data = httptools.downloadpage(src).data
        url = re.findall("source: '([^']+)'", data)[0]  # source: 'https://e7.cdn4.us/ingest666/orlandocitysh.m3u8'
        logger(url)
        return url + url_head

    elif 'video.olimp-app.ru' in src:
        logger("resolver: video.olimp-app.ru encontrado")
        url_head = '|Referer=%s' % urllib.quote(src)
        data = httptools.downloadpage(src).data
        url = re.findall('"file": "([^"]+)',data)[0].replace('\\/','/')
        url = ('https:' + url) if not url.startswith('https') else url
        logger(url)
        return url + url_head

    elif 'assia.tv' in src:
        logger("resolver: assia.tv encontrado")
        url_head = '|Referer=%s' % urllib.quote(src)
        data = httptools.downloadpage(src).data
        try:
            url = re.findall("source: '([^']+)'", data)[0]
        except:
            url = re.findall('file:"([^"]+)', data)[0]
        logger(url)
        return url + url_head

    elif 'sportlive.site' in src:
        logger("resolver: sportlive.site encontrado")
        data = httptools.downloadpage(src).data
        url = re.findall('<iframe src="([^"]+)"', data)
        return get_url(url, referer=src)

    elif 'livesport4u.pw' in src:
        logger("resolver: livesport4u.pw encontrado")
        #url_head = '|Referer=%s' % src
        data = httptools.downloadpage(src, headers={'Referer': src}).data
        #logger(data)
        id, url = re.findall("<script type='text/javascript'>id='([^']+).*? src='([^']+)", data)[0]
        return get_url(url, id=id)

    elif 'pcast.pw' in src:
        logger("resolver: pcast.pw encontrado")
        src = 'http://pcast.pw/embed/%s.php?width=700&height=480&stretching=uniform' % kwargs.get('id', 'none')
        data = httptools.downloadpage(src).data
        url = re.findall('<iframe src="([^"]+)".*?allowfullscreen="true"', data)[0]
        return get_url(url, referer=src)

    elif 'livestream.com' in src:
        logger("resolver: livestream.com encontrado")
        url_head = '|Referer=%s' % urllib.quote(src)
        data = httptools.downloadpage(src).data
        url = re.findall('"m3u8_url":"([^"]+)', data)[0]
        logger(url)
        return url + url_head

    elif 'whd365.pro' in src:
        logger("resolver: whd365.pro encontrado")
        #url_head = '|Referer=%s' % urllib.quote(src)
        data = httptools.downloadpage(src).data

        data_channel = re.findall('data-channel="([^"]+)"', data)
        if data_channel:
            host = httptools.downloadpage('https://api.livesports24.online/gethost').data
            if host:
                url = "https://%s/%s.m3u8" %(host,data_channel[0])
                logger(url)
                return url



    elif 'streamcdn.to' in src:
        #TODO terminar
        logger("resolver: streamcdn.to encontrado")
        data = httptools.downloadpage(src, headers={'Referer': referer}).data
        logger(data)
        logger('streamcdn.to')
        raise()





        '''elif 'harleyquinnwidget' in src:
        logger("resolver: harleyquinnwidget encontrado")
        data = httptools.downloadpage(src).data
        headers = {'Referer': src}
        id = re.findall('<script type="text/javascript"> fid="([^"]+)', data)[0]
        src = "http://www.jokerplayer.net/embed.php?u=%s&vw=640&vh=360" % id
        data = httptools.downloadpage(src, headers=headers).data
        url_head = '|Referer=%s' % urllib.quote(src)
        url = re.findall('<iframe .*? src=([^\s]+) .*?allowfullscreen=true', data)[0]
        # JavaScript
        '''


    else:
        logger("No resolver for: %s" % src)
        # TODO
        # http://live-stream365.com/onlineplayer.php?stream_id=924570
        # http://foot.futbol/f12.php
        # http://live.harleyquinnwidget.live/freelivematch/7338752699424060.html

    return ret


