# -*- coding: utf-8 -*-

import urllib, urllib2
import re

from libs.tools import *

# v2
def list_all_channels(item):
    itemlist = list()

    data = httptools.downloadpage('https://www.flipax.net/t9303-champions-fase-de-grupos-jornada-2-de-6-en-directo-iptv-acestream').data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    logger (data)